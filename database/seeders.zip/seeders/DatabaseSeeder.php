<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        /*
         * Untuk saat ini dikosongkan dulu.
         *
         * Data kabupaten, kecamatan, dan desa
         * diimport melalui command:
         *
         * php artisan import:jateng
         *
         * Jangan panggil KabupatenSeeder, KecamatanSeeder,
         * DesaSeeder, atau WilayahSeeder agar data tidak dobel.
         */
    }
}